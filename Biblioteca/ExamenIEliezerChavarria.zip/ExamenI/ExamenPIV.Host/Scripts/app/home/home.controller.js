﻿app.controller('homeController', ['$scope', function ($scope) {
    $scope.saludo = 'Hola mundo!';
}]);