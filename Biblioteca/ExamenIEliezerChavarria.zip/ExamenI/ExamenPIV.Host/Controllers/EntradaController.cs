﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using ExamenPIV.Data;
using ExamenPIV.Data.Modelos;

namespace ExamenPIV.Host.Controllers
{
    public class EntradaController : ApiController
    {
        ExamenIPivContext ExamenContext = new ExamenIPivContext("ExamenIPVI");
        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                ExamenContext.Dispose();
            }
            base.Dispose(disposing);
        }

        // GET: api/Entrada
        [HttpGet]
        public IEnumerable<Entrada> Get()
        {
            return ExamenContext.Entradas;
        }

        // POST: api/Entrada
        public IHttpActionResult Post(Entrada nuevaEntrada)
        {
           if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            ExamenContext.Entradas.Add(nuevaEntrada);
            ExamenContext.SaveChanges();
            return Ok(nuevaEntrada);
        }
    }
}
