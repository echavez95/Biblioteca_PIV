﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;


namespace ExamenPIV.Host.Controllers
{

    public class CalculadoraController : ApiController
    {
        // GET: api/Calculadora
        [Route("api/Calculadora/{numero}")]
        [HttpGet]
        public IHttpActionResult Get(int numero)
        {
            return Ok(numero * 2);
        }

        // GET: api/Calculadora/5
        [Route("api/Calculadora/Suma/{numero1}/{numero2}")]
        [HttpGet]
        public IHttpActionResult Sumar(int numero1, int numero2)
        {
            return Ok(numero1 + numero2);
        }

    }
}
