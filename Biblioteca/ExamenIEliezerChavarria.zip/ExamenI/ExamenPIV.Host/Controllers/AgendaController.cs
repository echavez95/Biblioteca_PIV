﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web.Http.Description;
using ExamenPIV.Data;
using ExamenPIV.Data.Modelos;

namespace ExamenPIV.Host.Controllers
{
    public class AgendaController : ApiController
    {
        ExamenIPivContext ExamenContext = new ExamenIPivContext("ExamenIPVI");
        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                ExamenContext.Dispose();
            }
            base.Dispose(disposing);
        }
        // GET: api/Agenda/5
        [ResponseType(typeof(Agenda))]
        public IHttpActionResult Get(int id)
        {
            var agenda = ExamenContext.Agendas.Include("entradas").Where(x=> x.id == id);
            if (agenda == null)
            {
                return NotFound();
            }
            return Ok(agenda);
        }

        // POST: api/Agenda
        [HttpPost]
        public IHttpActionResult Post(Agenda nuevaAgenda)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            ExamenContext.Agendas.Add(nuevaAgenda);
            ExamenContext.SaveChanges();
            return Ok(nuevaAgenda);
        }

        [Route("api/Agenda/{idAgenda}/Entradas/{idEntrada}")]
        [HttpPost]
        public IHttpActionResult AgregarEntrada(int idAgenda, int idEntrada)
        {
            var agenda = ExamenContext.Agendas.Find(idAgenda);
            var entrada = ExamenContext.Entradas.Find(idEntrada);
            if(agenda==null || entrada == null)
            {
                return NotFound();
            }
            agenda.addEntrada(entrada);
            ExamenContext.SaveChanges();
            return Ok();
        }
    }
}
