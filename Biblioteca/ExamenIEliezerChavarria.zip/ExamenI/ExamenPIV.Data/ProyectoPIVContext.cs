﻿using System.Data.Entity;
using ExamenPIV.Data.Modelos;

namespace ExamenPIV.Data
{
    public class ExamenIPivContext: DbContext
    {
        public ExamenIPivContext() { }
        public ExamenIPivContext(string connectionName):base(connectionName)
        {

        }

        public DbSet<Entrada> Entradas { get; set; }
        public DbSet<Agenda> Agendas { get; set; }

    }
}
