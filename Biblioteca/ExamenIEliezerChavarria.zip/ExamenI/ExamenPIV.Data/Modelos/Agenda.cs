﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExamenPIV.Data.Modelos
{
    public class Agenda
    {
        public Agenda()
        {
            this.entradas = new List<Entrada>();
        }
        public int id { get; set; }
        public string nombre { get; set; }
        public IList<Entrada> entradas { get; set; }

        public void addEntrada(Entrada nuevaEntrada)
        { 
            entradas.Add(nuevaEntrada);
        }
    }
}
